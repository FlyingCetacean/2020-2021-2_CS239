declare function BMapCoordSys(bmap: any, api: any): void;
declare namespace BMapCoordSys {
    var dimensions: any;
    var create: (ecModel: any, api: any) => void;
}
export default BMapCoordSys;
