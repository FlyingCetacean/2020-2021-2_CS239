

var pollutants = ['PM2.5', 'PM10', 'SO2', 'NO2', 'CO', 'O3']

var data = []
for (var i = 0; i < pollutants.length; i++) {
  var tmp = [
    (i + 1) * 30,
    (i + 4) * i * 10,
    (i + 1) * 40,
    (i + 5) * i * i * 5 + 10,
    (i + 1) * 50,
    (i + 1) * 45,
    i * 75,
    i * 20,
    (i + 1) * 67,
    i * 56,
    i * 45,
    i * 50,
  ]
  data[i] = tmp
}

function draw(type) {
  var index = [12, 11]
  index.push(type)
  histogram(chosen_geo.province,chosen_geo.city,{
    year: 2013,
    month: 1,
    day: 2,
  })
  Heatmap(csv_data, index, start_date, end_date, timing_type)
}



  // 返回对象，内部包含两个成员：省份、城市

  